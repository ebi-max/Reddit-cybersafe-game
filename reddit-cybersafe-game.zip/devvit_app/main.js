// devvit_app/main.js
// Simple Devvit Web app stub for Reddit CyberSafe Game

import { Devvit } from '@devvit/public-api';

Devvit.configure({ redditAPI: true });

// Register a simple page that shows the game UI
Devvit.addPage({
  id: 'cybersafe-game',
  title: 'Reddit CyberSafe Game',
  render: ({ mount }) => {
    const root = document.createElement('div');
    root.style.fontFamily = 'Segoe UI, Tahoma, Geneva, Verdana, sans-serif';
    root.style.padding = '20px';
    root.style.maxWidth = '720px';
    root.innerHTML = `
      <h1>🧠 Reddit CyberSafe Game</h1>
      <p>Spot the phishing message! Choose which message is safe to click.</p>
      <div id="game-area">
        <div id="message-box" style="background:#f2f2f2;padding:16px;border-radius:8px;margin:12px 0;">Loading challenge...</div>
        <div style="display:flex;gap:10px;justify-content:center;">
          <button id="scam-btn" style="padding:10px 14px;border-radius:8px;background:#d93025;color:#fff;border:none;cursor:pointer;">🚨 Scam</button>
          <button id="safe-btn" style="padding:10px 14px;border-radius:8px;background:#1a73e8;color:#fff;border:none;cursor:pointer;">✅ Safe</button>
        </div>
        <div id="feedback" style="margin-top:12px;font-weight:600;"></div>
        <div id="scoreboard" style="margin-top:14px;">Score: <span id="score">0</span></div>
      </div>
    `;
    mount(root);

    const messages = [
      { text: "You’ve won a free iPhone! Click this link to claim.", scam: true },
      { text: "Your Reddit password was changed successfully.", scam: false },
      { text: "Congratulations! You are our lucky winner! Visit xyz.ru now.", scam: true },
      { text: "You requested a 2FA code. If this wasn’t you, secure your account.", scam: false },
      { text: "We’ve detected unusual login activity. Please verify at safe-reddit-check.net.", scam: true },
    ];

    let score = 0;
    let round = 1;
    let current = null;
    const messageBox = root.querySelector('#message-box');
    const feedback = root.querySelector('#feedback');
    const scoreDisplay = root.querySelector('#score');
    const scamBtn = root.querySelector('#scam-btn');
    const safeBtn = root.querySelector('#safe-btn');

    function nextMessage(){
      if(round > 5){
        messageBox.innerText = "🎉 Game Over! Final Score: " + score;
        feedback.innerText = "";
        scamBtn.style.display = 'none';
        safeBtn.style.display = 'none';
        return;
      }
      current = messages[Math.floor(Math.random()*messages.length)];
      messageBox.innerText = current.text;
      feedback.innerText = '';
    }

    function handleChoice(isScam){
      if(!current) return;
      if(isScam === current.scam){ feedback.innerText = '✅ Correct!'; score += 10; }
      else { feedback.innerText = '❌ Incorrect.'; }
      scoreDisplay.innerText = score;
      round++;
      setTimeout(nextMessage, 700);
    }
    scamBtn.addEventListener('click', ()=> handleChoice(true));
    safeBtn.addEventListener('click', ()=> handleChoice(false));
    nextMessage();
  }
});

export default Devvit;
