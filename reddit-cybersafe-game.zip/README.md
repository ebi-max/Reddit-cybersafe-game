# Reddit CyberSafe Game 🎮🔐

A simple interactive Reddit game built for the **Reddit x Kiro Community Games Challenge (2025)**.
It teaches users to detect phishing and scam messages through quick, fun choices.

## Files included
- `devvit_app/main.js` — Devvit page that runs the game UI
- `devvit_app/manifest.json` — Devvit app manifest
- `kiro/config.json` — Kiro project config placeholder
- `package.json` — npm metadata

## How to upload
1. Go to your GitHub repo: https://github.com/your-username/reddit-cybersafe-game
2. Click **Add file → Upload files**
3. Drag the contents of this ZIP (not the outer folder) into the upload area so files appear in the repo root:
   - `devvit_app/`
   - `kiro/`
   - `package.json`
   - `README.md`
4. Commit changes.
5. Open **Code → Codespaces → Create codespace on main** to start a workspace with these files.

## Next steps
- Open `devvit_app/main.js` and replace UI/logic with any improvements
- Deploy to Devvit Web by copying `main.js` into the Reddit Devvit editor or use Devvit CLI
