export default function autoscore(player, result) {
  console.log(`Player: ${player}, Result: ${result}`);
  return { success: true, player, result };
}
