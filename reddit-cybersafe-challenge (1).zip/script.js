const messages = [
  { text: "You’ve won a free iPhone! Click this link to claim.", scam: true },
  { text: "Your Reddit password was changed successfully.", scam: false },
  { text: "Congratulations! You are our lucky winner! Visit xyz.ru now.", scam: true },
  { text: "You requested a 2FA code. If this wasn’t you, secure your account.", scam: false },
  { text: "We’ve detected unusual login activity. Please verify at safe-reddit-check.net.", scam: true },
];

let score = 0;
let round = 1;
let current;
const messageBox = document.getElementById("message-box");
const feedback = document.getElementById("feedback");
const scoreDisplay = document.getElementById("score");
const roundDisplay = document.getElementById("round");
const scamBtn = document.getElementById("scam-btn");
const safeBtn = document.getElementById("safe-btn");

function nextMessage() {
  if (round > 5) {
    messageBox.innerText = "🎉 Game Over! Final Score: " + score;
    feedback.innerText = "";
    scamBtn.style.display = "none";
    safeBtn.style.display = "none";
    return;
  }
  current = messages[Math.floor(Math.random() * messages.length)];
  messageBox.innerText = current.text;
  feedback.innerText = "";
}
function handleChoice(isScam) {
  if (isScam === current.scam) {
    feedback.innerText = "✅ Correct!";
    score += 10;
  } else {
    feedback.innerText = "❌ Incorrect.";
  }
  scoreDisplay.innerText = score;
  round++;
  roundDisplay.innerText = round;
  setTimeout(nextMessage, 800);
}
scamBtn.addEventListener("click", () => handleChoice(true));
safeBtn.addEventListener("click", () => handleChoice(false));
nextMessage();
