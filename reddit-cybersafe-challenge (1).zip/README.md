# Reddit CyberSafe Challenge

An AI-powered community game that tests Redditors' ability to spot phishing or scam messages.
Built for the Reddit x Kiro Hackathon 2025.

## 🧠 Concept
Players are shown random messages and must decide whether they’re safe or scams.
Each correct answer increases the score.

## 🧩 Tech Stack
- Devvit Web
- HTML, CSS, JS
- Kiro hooks for automation

## ⚙️ How to Run
1. Clone this repo
2. Open `index.html` in your browser
3. Play the game

## 🧠 Author
**Ebieme Bassey**
Founder, EBIKLEAN Integrated Services
